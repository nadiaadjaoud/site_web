-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 28 août 2020 à 15:37
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `memoire`
--

-- --------------------------------------------------------

--
-- Structure de la table `antc`
--

DROP TABLE IF EXISTS `antc`;
CREATE TABLE IF NOT EXISTS `antc` (
  `idantc` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id` int(10) UNSIGNED NOT NULL,
  `antmed` text DEFAULT NULL,
  `antch` text DEFAULT NULL,
  `antfam` text DEFAULT NULL,
  `autre` text DEFAULT NULL,
  PRIMARY KEY (`idantc`),
  KEY `fk_antc_numero` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `fichepat`
--

DROP TABLE IF EXISTS `fichepat`;
CREATE TABLE IF NOT EXISTS `fichepat` (
  `idfiche` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id` int(10) UNSIGNED NOT NULL,
  `diag` text DEFAULT NULL,
  `poid` text DEFAULT NULL,
  `taille` text DEFAULT NULL,
  `signph` text DEFAULT NULL,
  `siegedl` text DEFAULT NULL,
  `motifv` text DEFAULT NULL,
  `signf` text DEFAULT NULL,
  `signg` text DEFAULT NULL,
  `remq` text DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idfiche`),
  KEY `fk_patient_numero` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `conf_email` varchar(50) NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `age` int(100) NOT NULL,
  `sexe` char(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`id`, `nom`, `prenom`, `email`, `conf_email`, `mdp`, `age`, `sexe`) VALUES
(1, 'docteur', 'saheb', 'doctorsaheb2001@gmail.com', 'doctorsaheb2001@gmail.com', '24ad37372b09a343411a62c42bf7ea468227378b', 50, 'H'),
(2, 'secretaire', 'secretaire', 'secretairedoc@gmail.com', 'secretairedoc@gmail.com', 'f8ca00a9f7474154a409ea891c97e38efc17335c', 30, 'F');

-- --------------------------------------------------------

--
-- Structure de la table `patient`
--

DROP TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `telephone` int(15) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mdp` varchar(50) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `jour` int(2) NOT NULL,
  `mois` int(2) NOT NULL,
  `annee` int(4) NOT NULL,
  `sit_fam` varchar(20) NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `patient`
--

INSERT INTO `patient` (`id`, `nom`, `prenom`, `telephone`, `email`, `mdp`, `adresse`, `jour`, `mois`, `annee`, `sit_fam`, `sexe`, `time`) VALUES
(1, 'adjaoud', 'nadia', 699505006, 'nadia_doudouche1999@hotmail.fr', '63d9c45f90255e79e982746c0bcb40383f201fc7', 'ait zellal', 19, 12, 1999, 'celibataire', 'femme', '2020-08-11 13:59:27'),
(2, 'Hmz', 'Abdenour', 555853489, '2008abdenour@live.fr', '8c65e9089691f51841deb452941e109e81e4eb86', 'Alger', 4, 5, 1999, 'celibataire', 'Homme', '2020-08-11 20:42:05'),
(3, 'adjaoud', 'amine', 699505006, 'amine2002@gmail.com', '23bc6df7647b818d79ce7fc43fa0f460c188205a', 'ait zellal', 12, 11, 2002, 'celibataire', 'Homme', '2020-08-11 23:04:52'),
(4, 'adjaoud', 'rachid', 699505006, 'rachid2001@gmail.com', 'af045d9e68f1279af589eff3a2682851ea4e8686', 'ait zellal', 5, 7, 2001, 'celibataire', 'Homme', '2020-08-27 17:19:22');

-- --------------------------------------------------------

--
-- Structure de la table `rdv`
--

DROP TABLE IF EXISTS `rdv`;
CREATE TABLE IF NOT EXISTS `rdv` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `prenom` text NOT NULL,
  `telephone` int(10) NOT NULL,
  `jour` int(31) NOT NULL,
  `mois` int(12) NOT NULL,
  `annee` int(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `antc`
--
ALTER TABLE `antc`
  ADD CONSTRAINT `fk_antc_numero` FOREIGN KEY (`id`) REFERENCES `patient` (`id`);

--
-- Contraintes pour la table `fichepat`
--
ALTER TABLE `fichepat`
  ADD CONSTRAINT `fk_patient_numero` FOREIGN KEY (`id`) REFERENCES `patient` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
